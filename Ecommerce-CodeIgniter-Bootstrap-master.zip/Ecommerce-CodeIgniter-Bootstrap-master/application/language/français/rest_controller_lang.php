<?php 
$lang['text_rest_invalid_api_key'] = 'Clé d&#39;API %s invalide';
$lang['text_rest_invalid_credentials'] = 'Informations d&#39;identification invalides';
$lang['text_rest_ip_denied'] = 'IP interdie';
$lang['text_rest_ip_unauthorized'] = 'IP non autorisée';
$lang['text_rest_unauthorized'] = 'Non autorisé';
$lang['text_rest_ajax_only'] = 'Seules les requêtes AJAX sont autorisées';
$lang['text_rest_api_key_unauthorized'] = 'Cette clé API n&#39;a pas accès au contrôleur demandé';
$lang['text_rest_api_key_permissions'] = 'Cette clé API n&#39;a pas assez d&#39;autorisations';
$lang['text_rest_api_key_time_limit'] = 'Cette clé API a atteint la limite de temps pour cette méthode';
$lang['text_rest_ip_address_time_limit'] = 'Cette adresse IP a atteint la limite de temps pour cette méthode';
$lang['text_rest_unknown_method'] = 'Méthode inconnue';
$lang['text_rest_unsupported'] = 'Protocole non pris en charge';
