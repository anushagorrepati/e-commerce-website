<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container">
    <div class="body">
        <div class="alert alert-success"><?= lang('paypal_cancel_msg') ?></div>
    </div>
</div>